import {build} from 'esbuild';
import {readFile,writeFile} from 'node:fs/promises';
const bundle=await build({entryPoints:['scene.js'],bundle:true,format:'iife',minify:true,write:false,legalComments:'inline',target:'es2020'});
const template=await readFile('template.html','utf8');
await writeFile('index.html',template.replace('/*APP_BUNDLE*/',()=>bundle.outputFiles[0].text.replace(/<\/script/gi,'<\\/script')));
console.log('完成：用浏览器打开 index.html 即可。');
