import { build } from 'esbuild';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
const result = await build({ entryPoints: ['src/scene.js'], bundle: true, format: 'iife', minify: true, write: false, target: 'es2020', legalComments: 'inline' });
const template = await readFile('src/page.html', 'utf8');
const html = template.replace('/* SCENE_BUNDLE */', () => result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script'));
await mkdir('dist', { recursive: true });
await writeFile('dist/index.html', html);
console.log(`Built self-contained page: ${(Buffer.byteLength(html) / 1024).toFixed(0)} KB`);
