import http from 'node:http';
import { readFile } from 'node:fs/promises';
http.createServer(async (req, res) => {
  if (req.url === '/' || req.url === '/index.html') {
    const html = await readFile(new URL('./dist/index.html', import.meta.url));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(html);
  } else { res.writeHead(404); res.end('Not found'); }
}).listen(4173, '127.0.0.1', () => console.log('Local: http://127.0.0.1:4173'));
